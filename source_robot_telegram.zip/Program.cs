﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NetTelegramBotApi;
using NetTelegramBotApi.Requests;
using NetTelegramBotApi.Types;
using System.Net;

namespace $safeprojectname$
{
    class Program
    {
        private static ReplyKeyboardMarkup mainmenu;
        private static string Token = "268565653:AAEvqDS2NdgLDS2zGAvSVs8WuLnpHqQMlRA"; // !
        private static long chID = -1001053364158;
        static void Main(string[] args)
        {
            mainmenu = new ReplyKeyboardMarkup
            {
                Keyboard = new[] { new[] { "لیست آموزش ها \U0001F4D5" }, new[] { "ارسال به کانال " }, new[] { "راهنما \U00002139", "درباره" } }
            };
            Task.Run(() => RunBot());
            Console.ReadLine();
        }
        public static async Task RunBot()
        {
            var bot = new TelegramBot(Token);
            var me = await bot.MakeRequestAsync(new GetMe());
            Console.WriteLine("username is {0}", me.Username);
            long offset = 0;
            int whilecount = 0;
            while (true)
            {
                Console.WriteLine("while count is {0}", whilecount);
                whilecount += 1;
                var updates = await bot.MakeRequestAsync(new GetUpdates() { Offset = offset });
                Console.WriteLine("update count is {0}", updates.Count());
                Console.WriteLine("=====================================");
                try
                {
                    foreach (var update in updates)
                    {
                        offset = update.UpdateId + 1;
                        var text = update.Message.Text;
                        if (text != null && text.Contains("ارسال به کانال"))
                        {
                            using (var stream = System.IO.File.Open("D://test.jpg", System.IO.FileMode.Open))
                            {
                                var req3 = new SendPhoto(chID, new FileToSend(stream, "test.jpg")) { Caption = "ارسال شده از ربات" };
                                await bot.MakeRequestAsync(req3);
                            }
                        }
                        else if (text == "/start")
                        {
                            var req = new SendMessage(update.Message.Chat.Id, "شما باید یک عکس بفرستید") { ReplyMarkup = mainmenu };
                            await bot.MakeRequestAsync(req);
                            continue;
                        }
                        else if (text != null && text.Contains("درباره"))
                        {
                            var req = new SendMessage(update.Message.Chat.Id, "learn-net.ir") { ReplyMarkup = mainmenu };
                            await bot.MakeRequestAsync(req);
                            continue;
                        }
                        else if (update.Message.Photo != null)
                        {
                            var req = new SendMessage(update.Message.Chat.Id, "تصویر شما دریافت شد ودر حال ذخیره سازی است") { ReplyMarkup = mainmenu };
                            await bot.MakeRequestAsync(req);

                            var fileid = update.Message.Photo.LastOrDefault().FileId;
                            var file = await bot.MakeRequestAsync(new GetFile(fileid));
                            savefile(file.FileDownloadUrl, "D://test.jpg");

                            var req2 = new SendMessage(update.Message.Chat.Id, "فایل را ذخیره کردم و دارم واترمارک می کنم") { ReplyMarkup = mainmenu };
                            await bot.MakeRequestAsync(req2);

                            //
                            using (var stream = System.IO.File.Open("D://test.jpg", System.IO.FileMode.Open))
                            {

                                var req3 = new SendPhoto(update.Message.Chat.Id, new FileToSend(stream, "test.jpg"));
                                await bot.MakeRequestAsync(req3);
                            }

                            continue;
                        }
                        else if (update.Message.Document != null && update.Message.Document.MimeType == "video/mp4")
                        {
                            var fileid = update.Message.Document.FileId;
                            var file = await bot.MakeRequestAsync(new GetFile(fileid));
                            savefile(file.FileDownloadUrl, "D://test.gif");

                            //

                            using (var stream = System.IO.File.Open("D://test.gif", System.IO.FileMode.Open))
                            {
                                var req3 = new SendDocument(update.Message.Chat.Id, new FileToSend(stream, "test.gif"));
                                await bot.MakeRequestAsync(req3);
                            }

                        }
                        else if (update.Message.ReplyToMessage != null)
                        {
                            if (update.Message.ReplyToMessage.Photo != null)
                            {
                                var fileid = update.Message.ReplyToMessage.Photo.LastOrDefault().FileId;
                                var req = new SendPhoto(update.Message.Chat.Id, new FileToSend(fileid)) { Caption = text };
                                await bot.MakeRequestAsync(req);
                                continue;
                            }
                        }
                        else
                        {
                            var req = new SendMessage(update.Message.Chat.Id, "دستوری که فرستادید مفهوم نبود") { ReplyMarkup = mainmenu };
                            await bot.MakeRequestAsync(req);
                            continue;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
            }

        }
        private static void savefile(string downloadurl, string filename)
        {
            using (WebClient mywebclient = new WebClient())
            {
                mywebclient.DownloadFile(downloadurl, filename);
            }
        }

    }
}